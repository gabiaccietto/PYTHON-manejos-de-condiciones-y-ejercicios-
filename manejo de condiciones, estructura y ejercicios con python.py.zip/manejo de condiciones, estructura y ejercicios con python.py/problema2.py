
# ESCRIBIR UN PROGRAMA QUE PREGUNTE AL USUARIO POR EL NUMERO DE HORAS TRABAJADAS Y EL COSTE POPR HORA TRABAJADAS. DESPUES DEBE MOSTRAR POR PANTALLA EL PAGO QUE CORRESPONDE 

'''paga=int(input("INGRESE SU PAGO POR HORAS:" ))
horas= int(input("INGRESE LA CANTIDAD DE HORA QUE TRABAJA :"))


print("EL PAGO QUE LE CORRESPONDE ES DE  : ","$", paga * horas )'''


#PREGUNTAR AL USUARIO UN MONTO A INVERTIR, EL INTERES ANUAL Y EL NUMERO DE AÑOS, MOSTRAR EL CAPITAL OBTENIDO POR LA INVERSION
'''
monto= float(input("INGRESE EL MONTO QUE DESEA INVERTIR: "))
interes_anual=float(input("INGRESE EL INTERES ANUAL: "))
ano_inversion= int(input("INGRESE LA CANTIDAD DE AÑOS A INVERTIR: "))

print("El capital obtenido por la inversion sera de : " "$",monto+(interes_anual/100)*ano_inversion)
'''

#CALCULAR EL PESO TOTAL DEL PEDIDO DE PAYASOS Y MUÑECAS
'''
peso_payaso=112
peso_muñeca=75
payaso= int(input("ingrese numero de payasos: "))
muñeca=int(input("ingrese numero de muñecas: "))

print("EL PESO TOTAL DEL PEDIDO ES DE :",peso_payaso*payaso+ peso_muñeca*muñeca )'''

#CALCULAR EL PAN VIEJO VENDIDO CON SU DESCUENTO
'''
pan_Del_dia=3.49
pan_Viejo=float(input("ingrese el pan viejo vendido :"))
print("EL PRECIO HABITUAL DE LAS BARRA QUE LLEVA DE PAN ES :", pan_Del_dia* pan_Viejo,"PERO COMO ELIGIO PAN VIEJO PARA LLEVAR SE LE HACE UN DESCUENTO DEL 60%,","","EL TOTAL DE LO QUE LLEVA DEL PAN VIEJO ES DE :", (pan_Viejo*pan_Del_dia)*(60/100 ))'''


#IGRESAR UNA INVERSION CADA AÑO HASTA LLEGAR A  3 Y MOSTRAR LA SUMA TOTAL, MAS SUS INTERES ANUALES DEL 4%
'''
interes=4
ano_Uno=  float(input("ingrese la inversion 1 : "))
print("SU PRIMER INVERSION ES DE : ","","$",round(ano_Uno*(interes/100)))

ano_Dos=  float(input("ingrese la inversion 2: "))
print("SU SEGUNDA  INVERSION ES DE : ","","$",round(ano_Dos*(interes/100)))

ano_Tres=  float(input("ingrese la inversion 3: "))
print("SU TERCERA INVERSION ES DE : ","","$",round(ano_Tres*(interes/100)))

print ("EL TOTAL DE SUS INVERSIONES A LOS LARGO DE ESTOS 3 AÑOS MAS INTERES EWS DE: ", "$",round (ano_Uno+ano_Uno*(interes/100)+ano_Dos+ano_Dos*(interes/100)+ano_Tres+ano_Tres*(interes/100)))'''

#RECORRER/IMPRIMIR PALABRA 10 VECES
'''
palabra=input("ingrese su palabra:")
for i in range (10):
    print (palabra)'''
    
    
#INGRESAR EDAD Y IMPRIMIR SU EDADES PASADAS
'''
edad=int(input("ingrese su edad:"))

for i in  range (edad):
    
print ("ENTONCES YA PASO  TU CUMPLEAÑOS N°: ",i-0)'''


#MENU CON PROBLEMA PARA ELEGIR

'''def Suma_numeros(num1,num2):
    print("LA SUMA TOTAL ES DE : ",num1+num2)

def Edad(num_edad):
    for i in range (num_edad):
     print("Entonces ya cumpliste:", i-0 )
     

def Capital_inversion (monto,interes_anual,ano_inversion):  
    print("El capital obtenido por la inversion sera de : " "$",monto+(interes_anual/100)*ano_inversion)  


    
pantalla=int(input("INGRESA EL NUMERO DE LA OPCION :\n " "1=SUMAR 2 NUMEROS\n" "2=IMPRIMIR TUS EDADES PASADAS\n" "3=IMPRIMIR TU INVERSION DE ACUEDO A INTERES Y AÑO\n"));


if  pantalla==1: 
    print( Suma_numeros(num1=int(input("ingresa numero 1 para sumar : ")),num2= int(input("ingresa numero 2 para sumar  :"))))
elif pantalla==2:
    print(Edad(num_edad=int(input("ingresa tu edad: "))))

elif pantalla==3:
    print(Capital_inversion(monto=float(input("INGRESA EL MONTO QUE QUIERES INVERTIR: $")),interes_anual=float(input("INGRESE EL INTERES ANUAL: ")),ano_inversion= int(input("INGRESE LA CANTIDAD DE AÑOS A INVERTIR: "))))

else:
    print("INGRESA UN NUMERO DE OPCION VALIDO")'''
    


   
   

