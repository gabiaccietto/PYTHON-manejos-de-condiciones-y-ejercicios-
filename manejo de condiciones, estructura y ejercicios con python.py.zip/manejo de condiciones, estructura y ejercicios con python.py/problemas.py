
#---------------------------PROBLEMA 1-------------------------------------------------
'''
class CuentaBancaria :
    def __init__(self, num_cuenta, nombre_titular,balance):
        self.num_cuenta = num_cuenta
        self.nombre =nombre_titular
        self.balance = balance
        
    def generar_balance(self):
        print(self.balance)
        
    def depositar(self,monto):
        if monto >0:
            self.balance += monto
            
    def cuenta(self):
        print( self.num_cuenta)
     
    def titular(self):
            print( self.nombre)
        
mi_cuenta = CuentaBancaria("105-356.654", "alberto accietto", 4000)



mi_cuenta.titular() 

mi_cuenta.cuenta() 
mi_cuenta.generar_balance()
mi_cuenta.depositar(2000)
mi_cuenta.generar_balance()'''


#-----------------------------------PROBLEMA 2-------------------------------------------

  
    
'''num_uno= float(input("ingresa el primer numero: "))
num_dos= float(input("ingresa tu segundo numero "))
suma= num_uno + num_dos
print('LA SUMA DE LOS DOS NUMEROS ES DE :',suma)'''

#-----------------------------------PROBLEMA 3-------------------------------------------





'''num_uno= float(input("ingresa el primer numero: "))
num_dos= float(input("ingresa tu segundo numero "))
suma= num_uno + num_dos
num_tres= float(input("ingresa el numero por el cual vas a multiplicar la suma:  "))
print('LA SUMA  mas la multiplicacion DE LOS NUMEROS ES DE :',suma*num_tres)'''



#-------------------------------------PROBLEMA 4-----------------------------------------



'''kilomentros=float(input("INGRESA LOS KILOMETROS RECORRIDOS: "))
litros= float(input("ingresa la cantidad de litros de nafta gastasdos : "))

print("HAZ GASTADO POR CADA KILOMETRO RECORRIDO :",kilomentros/litros, "litros de nafta")'''



#-------------------------------------PROBLEMA 5------------------------------------------

'''fahrenheit= float(input("ingresa la temperatura en la escala fahrenheit: "))
print("CELSIUS: ", (5/9)*(fahrenheit-32))'''

#----------------------------------------PROBLEMA 6-------------------------------------------


'''lista=[]

x=0
carga= int(input("INGRESAR CUANTAS COTIZACIONES DESEAS AGREGAR A LA LISTA: "))


while x< carga :
    meses=str(input("ingresa el mes de de cotizacion:  "))
    cotizacion= float(input("ingresa la ctizacion de ese mes : $ "))
    nueva_cotizacion={"MES": meses, "COTIZO ": cotizacion}
    print("------------------------------------------------------")
    lista.append(nueva_cotizacion)
    x+=1    
print("LAS COTIZACIONES SON: ",lista)'''
    

#----------------------------------------PROBLEMA 7--------------------------------------------------


'''
dolar=250
euro=340

carga=int(input("INGRESA EL TIPO DE CAMBIO:  1-PESO A DOLAR, 2-PESO A EURO, 3-DOLAR A PESO, 4-EURO A PESO, 5-EURO A DOLAR, 6-DOLAR A EURO: "))

if carga == 1 :
    peso=int(input("INGRESA LOS PESOS: "))
    print("El cambio es :","USD",peso/dolar)

elif carga == 2 :
     peso=int(input("INGRESA LOS PESOS: "))
     print("El cambio es :","EUR",peso/euro)
     
elif carga == 3 :
     dolar=int(input("INGRESA LOS DOLARES " ))
     print("El cambio es :","$",dolar*250)

elif carga == 4 :
       
     euro=int(input("INGRESA LOS EUROS " ))
     print("El cambio es :","$",euro*300)


elif carga == 5 :
       
     euro=int(input("INGRESA LOS EUROS " ))
     print("El cambio es :","USD",euro*1.02)
     
elif carga == 6 :
       
     euro=int(input("INGRESA LOS DOLARES " ))
     print("El cambio es :","EUR",euro*0.98)

    
    
'''

     
    

