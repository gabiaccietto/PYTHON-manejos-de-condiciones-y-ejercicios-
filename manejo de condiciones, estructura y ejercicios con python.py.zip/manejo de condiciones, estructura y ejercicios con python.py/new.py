consulta= int(input("Ingrese un numero: "))
consulta_dos= int(input("Ingrese un segundo numero: "));

if consulta < consulta_dos :
    print(consulta,"ES MENOR Y EL MAYOR ES :  ",consulta_dos);
    
elif consulta == consulta_dos :
    print("SON IGUALES");


else:
    print(consulta," ES  MAYOR , Y EL MENOR ES : ", consulta_dos);
    
    
    
    