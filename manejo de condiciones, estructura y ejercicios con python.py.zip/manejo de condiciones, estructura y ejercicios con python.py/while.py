
'''x=20

while   x    : 
    print (x)'''
    
    


''''usuarios=[]
 
carga=int(input("cuantos usuarios quieres cargar: "))
x=0


while x< carga:
    usuario= input("ingresa tu usuario: ")
    contraseña=input("ingresa tu contraseña: ")
    nuevo_usuario={"usuario": usuario,"contraseña": contraseña}
    usuarios.append(nuevo_usuario)
    
    x+=1
    print(usuarios)'''
    
   
'''print ("sentencia terminada con 0")
suma=0
numeros=int(input("ingresa numeros: "))
while numeros!=0 :
     suma+=numeros
     numeros=int(input("ingresa numeros: "))
print("LA SUMA DE TODOS LOS NUMEROS ES : ",suma)'''



#Escriba un programa que pregunte una y otra vez si desea continuar con el programa, siempre que se conteste exactamente sí (en minúsculas y con tilde).
    




'''print("DIGA si PARA SEGUIR")
pregunta =input( "Deseas seguir con el programa?: ")

while pregunta == "si":
    pregunta =input( "Deseas seguir con el programa?: ")
print(" NO QUISISTE SEGUIR :(")'''
    
   



    
   
'''pregunta =input("deseas terminar el programa : ")
while pregunta != "SI":
    pregunta =input("deseas terminar el programa : ")
print("SE TERMINO EL PROGRAMA HASTA A PROXIMA ")'''


'''print("CONFIRMA TU CONTRASEÑA")

contraseña=input("ingresa tu contraseña : ")

contraseña_dos=input("ingresa tu contraseña : ")

while contraseña != contraseña_dos:
    contraseña=input("ingresa tu contraseña : ")
    contraseña_dos=input("ingresa tu contraseña nuevamente : ")
print("las contra son iguales ") '''



'''cantidad=float(input("INGRESA LA CANTIDAD QUE QUIERES AHORRAR EN LA CUENTA : ")) 
ahorros=0

while ahorros <= cantidad:
    ahorros+=float(input("INGRESA TUS AHORROS: "))
print("tus ingresos en cuenta son de : ", ahorros)
'''






